#!/bin/bash
chmod +x /tmp/main