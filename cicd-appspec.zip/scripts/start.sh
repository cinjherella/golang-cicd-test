#!/bin/bash
/tmp/main > /tmp/output.txt