#!/bin/bash
aws s3 cp s3://golang-cicd-test/app/main /tmp/
